<!-- eslint-disable vue/multi-word-component-names -->
<template>
	<div class="b-example-divider"></div>
	<div class="container">
		<hr />
		<footer class="py-3 my-4">
			<p class="text-center text-body-secondary">&copy; 2023 Company, Inc</p>
		</footer>
	</div>
	<div class="b-example-divider"></div>
</template>
